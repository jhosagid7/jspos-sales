<?php

namespace App\Livewire;

use App\Models\Sale;
use App\Models\DeliveryLocation;
use Livewire\Component;
use Illuminate\Support\Facades\Auth;

class DriverDashboard extends Component
{
    public $driverId;
    public $viewingAsAdmin = false;
    public $sales;
    public $historySales;
    public $tab = 'pending'; // pending, history
    
    // Collection
    public $selectedSaleId = null;
    public $selectedSaleTotal = 0;
    public $collectionNote = '';
    public $collectionPayments = []; // [{currency_id, amount, exchange_rate}]
    public $existingCollections = [];
    
    // Monitoring
    public $hasMonitoringPermission = false;
    public $driversList = [];

    public function mount($driverId = null)
    {
        $this->hasMonitoringPermission = Auth::user()->can('driver_monitoring') || Auth::user()->hasRole('Admin');
        
        // If driverId is provided and user has permission
        if ($driverId && ($this->hasMonitoringPermission || $driverId == Auth::id())) {
            $this->driverId = $driverId;
            $this->viewingAsAdmin = ($driverId != Auth::id());
        } else {
            $this->driverId = Auth::id();
        }

        if ($this->hasMonitoringPermission) {
            $this->loadDriversList();
        }
        
        $this->loadSales();
    }

    public function loadDriversList()
    {
        // Get all users with driver role or that have sales assigned
        $this->driversList = \App\Models\User::whereHas('roles', function($q) {
                $q->whereIn('name', ['Driver', 'Chofer', 'repartidor', 'driver']);
            })
            ->orWhereIn('id', Sale::whereNotNull('driver_id')->pluck('driver_id')->unique())
            ->orderBy('name')
            ->get();
    }

    public function updatedDriverId()
    {
        $this->viewingAsAdmin = ($this->driverId != Auth::id());
        $this->loadSales();
        $this->reset(['selectedSaleId', 'selectedSaleTotal', 'existingCollections', 'collectionNote', 'collectionPayments']);
    }

    public function loadSales()
    {
        // Active Sales (Pending or In Transit)
        $this->sales = Sale::where('driver_id', $this->driverId)
            ->whereIn('delivery_status', ['pending', 'in_transit'])
            ->with('customer')
            ->orderBy('created_at', 'asc') // Oldest first for delivery priority
            ->get();

        // History Sales (Delivered or Cancelled) - Last 50
        $this->historySales = Sale::where('driver_id', $this->driverId)
            ->whereIn('delivery_status', ['delivered', 'cancelled'])
            ->with('customer')
            ->orderBy('delivered_at', 'desc') // Newest delivered first
            ->take(50)
            ->get();
    }

    public function setTab($tab)
    {
        $this->tab = $tab;
    }

    public function updateStatus($saleId, $status, $lat, $lng)
    {
        $sale = Sale::where('id', $saleId)->where('driver_id', $this->driverId)->first();

        if ($sale) {
            $sale->delivery_status = $status;
            if ($status == 'delivered') {
                $sale->delivered_at = now();
            }
            $sale->save();

            DeliveryLocation::create([
                'sale_id' => $sale->id,
                'latitude' => $lat,
                'longitude' => $lng,
                'status_at_capture' => $status
            ]);

            $this->loadSales(); // Reload to move to history if delivered
            $this->dispatch('msg-ok', 'Estado actualizado correctamente');
        } else {
            $this->dispatch('msg-error', 'Pedido no encontrado o no asignado');
        }
    }

    public function startAllRoutes($lat, $lng)
    {
        // For admin monitoring, prevent actual updates
        if ($this->viewingAsAdmin) {
            $this->dispatch('msg-error', 'Solo el chofer asignado puede iniciar sus rutas');
            return;
        }

        $pendingSales = Sale::where('driver_id', $this->driverId)
            ->where('delivery_status', 'pending')
            ->get();
            
        if ($pendingSales->isEmpty()) {
            $this->dispatch('msg-error', 'No hay rutas pendientes por iniciar');
            return;
        }

        foreach ($pendingSales as $sale) {
            $sale->update(['delivery_status' => 'in_transit']);
            
            DeliveryLocation::create([
                'sale_id' => $sale->id,
                'latitude' => $lat,
                'longitude' => $lng,
                'status_at_capture' => 'in_transit'
            ]);
        }
        
        $this->loadSales();
        $this->dispatch('msg-ok', count($pendingSales) . ' rutas iniciadas correctamente');
    }

    public function selectSale($saleId)
    {
        $this->selectedSaleId = $saleId;
        
        // Find sale total
        $sale = $this->sales->firstWhere('id', $saleId);
        $this->selectedSaleTotal = $sale ? $sale->total : 0;

        // Fetch existing collections
        $this->existingCollections = \App\Models\DeliveryCollection::where('sale_id', $saleId)
            ->with(['payments.currency'])
            ->orderBy('created_at', 'desc')
            ->get();

        $this->collectionNote = '';
        // Initialize payments with one empty row or default currency
        $this->collectionPayments = [];
        $this->addPaymentRow();
        
        $this->dispatch('show-collection-modal');
    }

    public function addPaymentRow()
    {
        $defaultCurrency = \App\Models\Currency::first();
        $this->collectionPayments[] = [
            'currency_id' => $defaultCurrency ? $defaultCurrency->id : null,
            'amount' => '',
            'exchange_rate' => $defaultCurrency ? $defaultCurrency->exchange_rate : 1
        ];
    }

    public function removePaymentRow($index)
    {
        unset($this->collectionPayments[$index]);
        $this->collectionPayments = array_values($this->collectionPayments);
    }

    public function saveCollection()
    {
        // Filter out empty payment rows (where amount is empty or 0)
        $this->collectionPayments = array_filter($this->collectionPayments, function($payment) {
            return !empty($payment['amount']) && $payment['amount'] > 0;
        });

        // If no payments and no note, show error
        if (empty($this->collectionPayments) && empty(trim($this->collectionNote))) {
            $this->addError('collectionNote', 'Debe ingresar al menos una nota o un pago.');
            return;
        }

        $this->validate([
            'selectedSaleId' => 'required|exists:sales,id',
            'collectionNote' => 'nullable|string|max:255',
            'collectionPayments.*.amount' => 'required|numeric|min:0.01',
            'collectionPayments.*.currency_id' => 'required|exists:currencies,id'
        ]);

        if (!$this->selectedSaleId) {
            $this->dispatch('msg-error', 'ID de pedido no válido. Por favor, cierre el modal e intente de nuevo.');
            return;
        }

        $collection = \App\Models\DeliveryCollection::create([
            'sale_id' => $this->selectedSaleId,
            'driver_id' => $this->driverId,
            'amount' => 0, 
            'note' => $this->collectionNote
        ]);

        foreach ($this->collectionPayments as $payment) {
            $currency = \App\Models\Currency::find($payment['currency_id']);
            \App\Models\DeliveryCollectionPayment::create([
                'delivery_collection_id' => $collection->id,
                'currency_id' => $payment['currency_id'],
                'amount' => $payment['amount'],
                'exchange_rate' => $currency ? $currency->exchange_rate : 1
            ]);
        }

        $this->dispatch('hide-collection-modal');
        $this->dispatch('msg-ok', 'Novedad registrada correctamente');
        
        $this->reset(['collectionPayments', 'collectionNote', 'selectedSaleId', 'selectedSaleTotal', 'existingCollections']);
        $this->loadSales(); // Refresh the sales list
    }

    public function updateDriverLocation($lat, $lng)
    {
        // Only update if the user is actually the driver (don't update if admin is viewing)
        if (Auth::id() == $this->driverId) {
            \App\Models\DriverLocation::create([
                'driver_id' => Auth::id(),
                'latitude' => $lat,
                'longitude' => $lng
            ]);
        }
    }

    public function render()
    {
        return view('livewire.driver-dashboard', [
            'currencies' => \App\Models\Currency::all()
        ])->layout('layouts.theme.app');
    }
}
