<?php

namespace App\Livewire;

use App\Models\User;
use Livewire\Component;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class AsignarPermisos extends Component
{
    public $search;
    public  $role, $roleSelectedId,  $permissionId;
    public $users = [], $roles = [];

    function mount()
    {
        // Check granular permission, fallback to Admin role for safety
        if (!auth()->user()->can('permissions.assign') && !auth()->user()->hasRole('Admin')) {
            abort(403, 'NO TIENES AUTORIZACIÓN PARA ACCEDER A ESTE MÓDULO');
        }

        session(['map' => '', 'child' => '', 'pos' => 'Asignación de Roles y Permisos']);

        $this->users = User::when(!auth()->user()->hasRole('Super Admin'), function($q) {
            $q->whereDoesntHave('roles', function($q2) {
                $q2->where('name', 'Super Admin');
            });
        })->orderBy('id')->get();
        $this->roles = Role::with('permissions')
            ->when(!auth()->user()->hasRole('Super Admin'), function($q) {
                $q->where('name', '!=', 'Super Admin');
            })
            ->orderBy('name')->get();
        if (count($this->roles) > 0) {
            $this->role = Role::find($this->roles[0]->id);
            $this->roleSelectedId = $this->role->id;
        }
    }


    public function render()
    {
        $permisos = Permission::when($this->search != null, function ($query) {
            $query->where('name', 'like', "%{$this->search}%");
        })->orderBy('name')->get();

        // Group and Translate Permissions
        $groupedPermissions = $permisos->groupBy(function ($item) {
            return explode('.', $item->name)[0];
        })->map(function ($group, $key) {
            $groupName = $this->translateGroup($key);
            return [
                'name' => $groupName,
                'permissions' => $group->map(function ($perm) {
                    $perm->display_name = $this->translatePermission($perm->name);
                    $perm->description = $this->getPermissionDescription($perm->name);
                    return $perm;
                })
            ];
        })->sortBy('name');

        return view('livewire.roles.asignar-permisos', [
            'permisos' => $permisos, // Keep for compatibility if needed, but we'll use groupedPermissions
            'groupedPermissions' => $groupedPermissions
        ]);
    }

    private function translateGroup($key)
    {
        $map = [
            'sales' => 'Ventas',
            'cash_register' => 'Caja',
            'products' => 'Productos',
            'categories' => 'Categorías',
            'customers' => 'Clientes',
            'suppliers' => 'Proveedores',
            'purchases' => 'Compras',
            'inventory' => 'Inventarios',
            'adjustments' => 'Ajustes de Inventario',
            'transfers' => 'Traspasos',
            'warehouses' => 'Depósitos',
            'users' => 'Usuarios',
            'roles' => 'Roles',
            'permissions' => 'Permisos',
            'reports' => 'Reportes',
            'settings' => 'Configuración',
            'production' => 'Producción',
            'distribution' => 'Distribución',
            'orders' => 'Ordenes Guardadas',
            'payments' => 'Abonos / Pagos',
            'commissions' => 'Comisiones',
            'customer_statement' => 'Estado de Cuenta',
            'soplados' => 'Fábrica Soplados',
        ];
        return $map[$key] ?? ucfirst($key);
    }

    private function translatePermission($name)
    {
        // Flatten key for translation check
        $flatName = str_replace('.', '_', $name);
        
        // Try to get specific translation from lang file
        $transName = __("permissions.{$flatName}.name");
        
        // If translation doesn't exist (returns key), fallback to logic
        if ($transName === "permissions.{$flatName}.name") {
             $parts = explode('.', $name);
             $action = $parts[1] ?? $name;

             $map = [
                'approve_deletion' => 'Aprobar Eliminación',
                'approve_return' => 'Aprobar Devolución',
                'index' => 'Ver / Listar',
                'create' => 'Crear',
                'edit' => 'Editar',
                'delete' => 'Eliminar',
                'import' => 'Importar',
                'open' => 'Abrir',
                'close' => 'Cerrar',
                'access' => 'Acceder',
                'pdf' => 'Generar PDF',
                'assign' => 'Asignar',
                'map' => 'Ver Mapa',
                'labels' => 'Generar Etiquetas',
                'void_today' => 'Anular pagos del día',
                'void_anytime' => 'Anular cualquier pago',
                'edit_commercial_config' => 'Editar Configuración Comercial',
                'edit_credit_config' => 'Editar Configuración de Crédito',
                'operator' => 'Operador (App)',
                'manager' => 'Manager (Aprobación)',
                'products.edit.inventory' => 'Editar Inventario',
                'products.edit.categories' => 'Editar Categorización',
                'products.edit.price_rules' => 'Editar Reglas de Precio',
                'reports.audit' => 'Auditoría de Stock',
             ];

             return $map[$name] ?? $map[$action] ?? ucfirst(str_replace('_', ' ', $action));
        }

        return $transName;
    }

    private function getPermissionDescription($name)
    {
         $flatName = str_replace('.', '_', $name);
         $desc = __("permissions.{$flatName}.description");
         return ($desc === "permissions.{$flatName}.description") ? '' : $desc;
    }

    function updatedRoleSelectedId()
    {
        $this->role = Role::find($this->roleSelectedId);
    }

    public function assignRole($userId, $roleId)
    {
        try {
            $user = User::find($userId);
            
            // Protect Super Admin user
            if ($user->hasRole('Super Admin') && !auth()->user()->hasRole('Super Admin')) {
                $this->dispatch('noty', msg: "No tienes permiso para modificar los roles del Super Admin");
                return;
            }

            $role = null;
            if ($roleId != 0) {
                $role = Role::find($roleId);
                // Protect Super Admin role
                if ($role->name === 'Super Admin' && !auth()->user()->hasRole('Super Admin')) {
                    $this->dispatch('noty', msg: "No tienes permiso para asignar el rol Super Admin");
                    return;
                }
            }

            // Asigna el rol al usuario
            if ($roleId == 0) {
                $user->syncRoles([]); //eliminar roles
            } else {
                $user->syncRoles([$role]); //asignar role
            }

            if ($roleId == 0) {
                $this->dispatch('noty', msg: "Se eliminaron los roles al usuario $user->name");
            } else {
                $this->dispatch('noty', msg: 'Se asignó el rol ' . $role->name . ' al usuario ' . $user->name);
            }

            $this->UpdateProfileRoleUser($userId, $this->getRoleName($roleId));
        } catch (\Exception $th) {
            $this->dispatch('noty', msg: "Error al intentar asignar el role: {$th->getMessage()} ");
        }
    }

    function assignPermission($permissionId, $checkState)
    {
        try {
            if ($this->roleSelectedId == null) {
                $this->dispatch('noty', msg: "Selecciona el role para asignar el permiso");
                return;
            }

            $role = Role::find($this->roleSelectedId);
            
            // Protect Super Admin role
            if ($role->name === 'Super Admin' && !auth()->user()->hasRole('Super Admin')) {
                $this->dispatch('noty', msg: "No tienes permiso para modificar permisos del Super Admin");
                return;
            }

            $permission = Permission::find($permissionId);

            if ($checkState) {
                // asignar el permiso al role
                $role->givePermissionTo($permission);
                $message = 'Se asignó';
            } else {
                // eliminar el permiso del role
                $role->revokePermissionTo($permission);
                $message = 'Se eliminó';
            }


            // feedback
            $this->dispatch('noty', msg: "$message el permiso  $permission->name  al rol  $role->name");
            //
        } catch (\Exception $th) {
            $this->dispatch('noty', msg: "Error al intentar asignar el permiso al role : {$th->getMessage()} ");
        }
    }

    function assignRevokeAllPermissions($checkState)
    {
        $role = Role::find($this->roleSelectedId);

        // Protect Super Admin role
        if ($role && $role->name === 'Super Admin' && !auth()->user()->hasRole('Super Admin')) {
            $this->dispatch('noty', msg: "No tienes permiso para modificar permisos del Super Admin");
            return;
        }

        $permissions = Permission::all();

        if ($role) {
            if ($checkState) {
                $role->syncPermissions($permissions);
                $message = "Se asignaron todos los permisos al role  $role->name";
            } else {
                $role->revokePermissionTo($permissions);
                $message = "Se revocaron todos los permisos al role  $role->name";
            }
            $this->dispatch('noty', msg: $message);
        } else {
            $this->dispatch('noty', msg: 'No se encuentra en sistema el role seleccionado');
        }
    }

    public function UpdateProfileRoleUser($userId = null, $role)
    {
        try {
            DB::beginTransaction();

            $order = User::findOrFail($userId);
            $order->update([
                'profile' => $role,

            ]);

            DB::commit();
        } catch (\Exception $th) {
            DB::rollBack();
            $this->dispatch('noty', msg: "Error al intentar actualizar el role $role del usuario \n {$th->getMessage()}");
        }
    }


    public function getRoleName($roleId)
    {
        $role = Role::where('id', $roleId)->first();
        return $role->name;
    }
}
