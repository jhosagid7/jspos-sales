<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeviceAuthorization extends Model
{
    protected $fillable = [
        'uuid',
        'name',
        'ip_address',
        'user_agent',
        'status',
        'last_accessed_at',
        'printer_name',
        'printer_width',
        'is_network',
        'printer_user',
        'printer_password',
    ];

    protected $casts = [
        'last_accessed_at' => 'datetime',
        'is_network' => 'boolean',
    ];

    public function getIsOnlineAttribute()
    {
        if (!$this->last_accessed_at) {
            return false;
        }
        return $this->last_accessed_at->diffInMinutes(now()) <= 10;
    }

    protected $appends = ['is_online'];
}
