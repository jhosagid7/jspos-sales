<?php

namespace App\Providers;

use App\Events\PrintEvent;
use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Event;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event string[] / class[] mappings for the application.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],
        \App\Events\SaleCreated::class => [
            \App\Listeners\SystemNotificationListener::class,
        ],
        \App\Events\PaymentReceived::class => [
            \App\Listeners\SystemNotificationListener::class,
        ],
        \App\Events\CargoCreated::class => [
            \App\Listeners\SystemNotificationListener::class,
        ],
        \App\Events\DescargoCreated::class => [
            \App\Listeners\SystemNotificationListener::class,
        ],
        'Illuminate\Auth\Events\Login' => [
            'App\Listeners\LoginSuccess',
        ],
        PrintEvent::class => [],
    ];

    /**
     * Register any events for your application.
     */
    public function boot(): void
    {
        //
    }

    /**
     * Determine if events and listeners should be automatically discovered.
     */
    public function shouldDiscoverEvents(): bool
    {
        return false;
    }
}
