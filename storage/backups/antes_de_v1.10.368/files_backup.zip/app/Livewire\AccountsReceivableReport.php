<?php

namespace App\Livewire;

use Carbon\Carbon;
use App\Models\Bank;
use App\Models\Sale;
use App\Models\Payment;
use Illuminate\Support\Facades\DB;
use Livewire\Component;
use App\Traits\PrintTrait;
use Livewire\Attributes\On;
use Livewire\WithPagination;
use App\Models\SaleReturn;
use App\Models\SaleReturnDetail;
use App\Models\SaleDetail;
use App\Models\ProductWarehouse;

use App\Traits\CollectionSheetTrait;

class AccountsReceivableReport extends Component
{
    use PrintTrait, WithPagination, CollectionSheetTrait;


    public $pagination = 10, $banks = [], $customer, $customer_name, $debt, $debt_usd, $dateFrom, $dateTo, $showReport = false, $status = 0;
    public $searchFactura;
    public $totales = 0, $sale_id, $details = [], $pays = [];
    public $history_sale_id;
    public $editingPaymentId, $editPaymentRef, $editPaymentAmount, $editPaymentDate, $editPaymentRate, $editPaymentComment;
    public $editApplyEarlyDiscount = false, $editApplyUsdDiscount = false;
    public $editEarlyDiscountAmount = 0, $editUsdDiscountAmount = 0;
    public $editEarlyDiscountPercent = 0, $editUsdDiscountPercent = 0;
    public $editEarlyDiscountReason = '', $editUsdDiscountReason = '';
    public $editSaleTotal = 0, $editSalePaid = 0, $editSaleDebt = 0;
    public $amount, $acountNumber, $depositNumber, $bank, $phoneNumber;
    public $currencies, $paymentCurrency;
    public $paymentMethod = 'cash'; // cash, nequi, deposit
    public $sellers = [], $seller_id;
    public $users = [], $user_id; // New properties
    public $groupBy = 'customer_id'; // Default group by
    public $overdue_filter = 'all';
    
    public $showPdfModal = false;
    public $pdfUrl = null;

    public function searchData()
    {
        $this->showReport = true;
    }

    function mount()
    {
        session()->forget('account_customer');
        $this->banks = Bank::orderBy('sort')->get();
        $this->currencies = \App\Models\Currency::orderBy('is_primary', 'desc')->orderBy('id', 'asc')->get();
        $this->paymentCurrency = $this->currencies->firstWhere('is_primary', 1)->code ?? 'COP';
        
        if (auth()->user()->can('sales.view_all')) {
            $this->sellers = \App\Models\User::sellers()->orderBy('name')->get();
            $this->users = \App\Models\User::orderBy('name')->get(); 
        } else {
            // Restricted view: only show themselves
            $this->sellers = \App\Models\User::where('id', auth()->id())->get();
            $this->users = \App\Models\User::where('id', auth()->id())->get();
            $this->seller_id = auth()->id();
            $this->user_id = auth()->id();
        }

        session(['map' => "TOTAL COSTO $0.00", 'child' => 'TOTAL VENTA $0.00', 'rest' => 'GANANCIA: $0.00 / MARGEN: 0.00%', 'pos' => 'Reporte de Cuentas por Cobrar']);

        if (request()->has('c')) {
            $customer = \App\Models\Customer::find(request()->c);
            if ($customer) {
                session(['account_customer' => $customer]);
                $this->customer = $customer;
                $this->showReport = true;
            }
        }
    }

    public function render()
    {
        // $this->customer =  session('sale_customer', null);
        $this->customer = session('account_customer', null);

        $reportData = $this->getReport();

        return view('livewire.reports.accounts-receivable-report', [
            'sales' => $reportData['sales'] ?? [],
            'debitNotes' => $reportData['debitNotes'] ?? []
        ]);
    }


    #[On('account_customer')]
    function setSupplier($customer = null)
    {
        session(['account_customer' => $customer]);
        $this->customer = $customer;
    }

    function getReport()
    {
        if (!$this->showReport) return [];

        // Validation: Ensure at least one filter is active or dates are consistent
        // User requested to allow empty filters to show all records
        // if ($this->customer == null && $this->dateFrom == null && $this->dateTo == null && $this->seller_id == null) {
        //     $this->dispatch('noty', msg: 'SELECCIONA LOS FILTROS PARA CONSULTAR');
        //     return [];
        // }
        
        // Check for incomplete date range only if no customer is selected (or enforce range always if dates are used)
        // Let's enforce that if one date is set, the other must be too, unless we want open-ended ranges.
        // For simplicity and consistency with user request:
        if (($this->dateFrom != null && $this->dateTo == null) || ($this->dateFrom == null && $this->dateTo != null)) {
            $this->dispatch('noty', msg: 'SELECCIONA AMBAS FECHAS (DESDE Y HASTA)');
            return [];
        }

        try {
            $query = Sale::with(['customer', 'payments', 'returns', 'paymentDetails'])
                ->where('type', 'credit')
                ->whereNotIn('status', ['returned', 'voided', 'cancelled', 'anulated']) // Full exclusion of inactive invoices
                ->when($this->status != 0, function ($query) {
                    $query->where('status', $this->status);
                })
                ->when($this->status == 0, function ($query) {
                    $query->where('status', '<>', 'paid'); // Hide paid by default
                })
                ->when($this->overdue_filter != 'all', function ($query) {
                    $sql = "DATEDIFF(NOW(), DATE_ADD(COALESCE(delivered_at, created_at), INTERVAL credit_days DAY))";
                    if ($this->overdue_filter == 'overdue') {
                        $query->whereRaw("$sql > 0");
                    } elseif ($this->overdue_filter == 'in_time') {
                        $query->whereRaw("$sql <= 0");
                    }
                })
                ->when($this->customer != null, function ($query) {
                    $query->where('customer_id', $this->customer['id']);
                })
                ->when($this->seller_id != null, function ($query) {
                    $query->whereHas('customer', function($q) {
                        $q->where('seller_id', $this->seller_id);
                    });
                })
                ->when(!empty(trim($this->searchFactura)), function ($query) {
                    $searchValue = trim($this->searchFactura);
                    $saleId = 0;
                    if (is_numeric($searchValue)) {
                        $saleId = (int)$searchValue;
                    } elseif (preg_match('/^[Ff]0*([1-9][0-9]*)$/', $searchValue, $matches)) {
                        $saleId = (int)$matches[1];
                    }
                    if ($saleId > 0) {
                        $query->where('id', $saleId);
                    }
                })
                ->when($this->user_id != null, function ($query) {
                    $query->where('user_id', $this->user_id);
                });

            // Force restriction if user cannot view all
            if (!auth()->user()->can('sales.view_all')) {
                $query->where('user_id', auth()->id());
            }

            // Apply date filter only if both dates are provided
            if ($this->dateFrom != null && $this->dateTo != null) {
                $dFrom = Carbon::parse($this->dateFrom)->startOfDay();
                $dTo = Carbon::parse($this->dateTo)->endOfDay();
                $query->whereBetween('created_at', [$dFrom, $dTo]);
            }

            // --- CALCULATE GLOBAL TOTALS BEFORE PAGINATION ---
            // We get a copy of the query results for totals to avoid breaking pagination
            $allSalesToTotal = $query->get();
            
            $this->totales = $allSalesToTotal->sum(function($sale) {
                $totalPaidUSD = $sale->payments->whereNotIn('status', ['pending', 'rejected', 'voided'])->sum(function($payment) use ($sale) {
                    $rate = $payment->exchange_rate > 0 ? $payment->exchange_rate : ($payment->currency == 'USD' ? 1 : ($sale->primary_exchange_rate > 0 ? $sale->primary_exchange_rate : 1));
                    $amountUSD = $payment->amount / $rate;
                    
                    $discountUSD = $payment->discount_applied ?? 0;
                    if ($payment->rule_type === 'overdue') {
                        return $amountUSD - $discountUSD;
                    } else {
                        return $amountUSD + $discountUSD;
                    }
                });
                
                $initialPaidUSD = $sale->paymentDetails->sum(function($detail) {
                    $rate = $detail->exchange_rate > 0 ? $detail->exchange_rate : 1;
                    return $detail->amount / $rate;
                });

                $totalReturnsUSD = $sale->returns->where('refund_method', 'debt_reduction')->where('status', 'approved')->sum(function($ret) use ($sale) {
                    $rate = $sale->primary_exchange_rate > 0 ? $sale->primary_exchange_rate : 1;
                    return $ret->total_returned / $rate;
                });

                $totalUSD = $sale->total_usd > 0 ? $sale->total_usd : ($sale->primary_exchange_rate > 0 ? $sale->total / $sale->primary_exchange_rate : $sale->total);
                return max(0, round($totalUSD - ($totalPaidUSD + $initialPaidUSD + $totalReturnsUSD), 4));
            });

            // --- ADD DEBIT NOTES TO TOTALS ---
            $debitNotesQuery = \App\Models\DebitNote::query()
                ->where('status', 'pending')
                ->when($this->customer != null, function ($query) {
                    $query->where('customer_id', $this->customer['id']);
                })
                ->when($this->dateFrom != null && $this->dateTo != null, function ($query) {
                    $dFrom = Carbon::parse($this->dateFrom)->startOfDay();
                    $dTo = Carbon::parse($this->dateTo)->endOfDay();
                    $query->whereBetween('created_at', [$dFrom, $dTo]);
                });

            $totalDebitNotesUSD = $debitNotesQuery->get()->sum(function($dn) {
                return $dn->amount / ($dn->exchange_rate > 0 ? $dn->exchange_rate : 1);
            });

            $this->totales += $totalDebitNotesUSD;

            $totalSale = $allSalesToTotal->sum(function($sale) {
                 $exchangeRate = $sale->primary_exchange_rate > 0 ? $sale->primary_exchange_rate : 1;
                 return $sale->total_usd > 0 ? $sale->total_usd : $sale->total / $exchangeRate;
            });

            $allSaleIds = $allSalesToTotal->pluck('id');
            $totalCost = DB::table('sale_details')
                ->join('products', 'sale_details.product_id', '=', 'products.id')
                ->whereIn('sale_details.sale_id', $allSaleIds)
                ->sum(DB::raw('sale_details.quantity * products.cost'));

            $profit = $totalSale - $totalCost;
            $margin = $totalSale > 0 ? ($profit / $totalSale) * 100 : 0;

            $map = "TOTAL COSTO $" . number_format($totalCost, 4);
            $child = "TOTAL VENTA $" . number_format($totalSale, 4);
            $rest = " GANANCIA: $" . number_format($profit, 4) . " / MARGEN: " . number_format($margin, 2) . "%";

            session(['map' => $map, 'child' => $child, 'rest' => $rest, 'pos' => 'Reporte de Cuentas por Cobrar']);
            $this->dispatch('update-header', map: $map, child: $child, rest: $rest);

            // --- FINAL PAGINATION FOR DISPLAY ---
            $sales = $query->orderBy('id', 'desc')->paginate($this->pagination);

            // Only show debit notes that are NOT linked to a sale (e.g. Saldo Inicial)
            $debitNotes = $debitNotesQuery->whereNull('sale_id')->orderBy('id', 'desc')->get();

            return [
                'sales' => $sales,
                'debitNotes' => $debitNotes
            ];

        } catch (\Exception $th) {
            $this->dispatch('noty', msg: "Error al intentar obtener el reporte \n {$th->getMessage()}");
            return [];
        }
    }

    public function getPdfParams()
    {
        return [
            'customer_id' => $this->customer ? $this->customer['id'] : null,
            'seller_id' => $this->seller_id,
            'user_id' => $this->user_id,
            'dateFrom' => $this->dateFrom,
            'dateTo' => $this->dateTo,
            'status' => $this->status,
            'overdue_filter' => $this->overdue_filter,
            'groupBy' => $this->groupBy,
            'searchFactura' => $this->searchFactura,
        ];
    }

    public function generatePdf()
    {
        $params = $this->getPdfParams();
        $params['download'] = 1;

        return redirect()->route('reports.accounts.receivable.pdf', $params);
    }

    public function openPdfPreview()
    {
        $this->pdfUrl = route('reports.accounts.receivable.pdf', $this->getPdfParams());
        $this->showPdfModal = true;
    }

    public function closePdfPreview()
    {
        $this->showPdfModal = false;
        $this->pdfUrl = null;
    }

    function initPayment($sale_id, $customer = null, $debt = null, $prefill = [])
    {
        $sale = Sale::find($sale_id);
        
        if (!$sale) {
            $this->dispatch('noty', msg: 'Venta no encontrada');
            return;
        }

        if (empty($customer)) {
            $customer = $sale->customer->name ?? '';
        }
        
        // Calcular deuda en USD (moneda base)
        $totalPaidUSD = $sale->payments->whereNotIn('status', ['pending', 'rejected', 'voided'])->sum(function($payment) {
            $rate = $payment->exchange_rate > 0 ? $payment->exchange_rate : 1;
            return $payment->amount / $rate;
        });
        
        // Calculate Returns applied to debt
        $totalReturnsOrig = $sale->returns->where('refund_method', 'debt_reduction')->sum('total_returned');
        $exchangeRateReturns = $sale->primary_exchange_rate > 0 ? $sale->primary_exchange_rate : 1;
        $totalReturnsUSD = $totalReturnsOrig / $exchangeRateReturns;
        
        $netTotalUSD = max(0, $sale->total_usd - $totalReturnsUSD);
        $debtUSD = max(0, $netTotalUSD - $totalPaidUSD);
        
        // Convertir deuda a moneda principal para mostrar al usuario
        $primaryCurrency = \App\Models\Currency::where('is_primary', true)->first();
        $debtInPrimary = $debtUSD * $primaryCurrency->exchange_rate;
        
        // Obtener configuración de crédito (usar Snapshot si existe)
        $allowDiscounts = false;
        
        $parsedSnapshot = \App\Services\CreditConfigService::parseCreditSnapshot($sale->credit_rules_snapshot);
        $rules = $parsedSnapshot['discount_rules'];
        $snapshotUsdDiscount = $parsedSnapshot['usd_payment_discount'];

        if (empty($sale->credit_rules_snapshot)) {
            $creditConfig = \App\Services\CreditConfigService::getCreditConfig($sale->customer, $sale->customer->seller);
            $rules = $creditConfig['discount_rules'];
            $snapshotUsdDiscount = null;
        }

        // Determine USD Discount
        $usdPaymentDiscountPercent = 0;
        $fixedUsdDiscountAmount = 0;

        if ($sale->is_foreign_sale || $snapshotUsdDiscount > 0 || ($sale->customer->usd_payment_discount ?? 0) > 0) {
             // Check Ved History
             $hasVedHistory = $sale->payments()->whereIn('currency', ['VED', 'VES'])->exists();
             
             if (!$hasVedHistory || auth()->user()->can('payments.force_discounts')) {
                 $allowDiscounts = true;
                 
                  if ($snapshotUsdDiscount !== null) {
                    $usdPaymentDiscountPercent = $snapshotUsdDiscount;
                } else {
                    $config = \App\Services\CreditConfigService::getCreditConfig($sale->customer, $sale->customer->seller);
                    $usdPaymentDiscountPercent = $config['usd_payment_discount'] ?? 0;
                }

                if ($usdPaymentDiscountPercent > 0) {
                     $fixedUsdDiscountAmount = $netTotalUSD * ($usdPaymentDiscountPercent / 100);
                     $fixedUsdDiscountAmount = round($fixedUsdDiscountAmount, 2);
                }
             }
        }
        
        // Calcular los días transcurridos desde que se CREÓ la venta
        $daysElapsed = \Carbon\Carbon::parse($sale->created_at)->diffInDays(\Carbon\Carbon::now());
        
        $adjustment = \App\Services\CreditConfigService::calculateDiscount($debtUSD, $daysElapsed, $rules);
        
        if (!$adjustment && auth()->user()->can('payments.force_discounts')) {
            $baseRule = $rules->where('rule_type', 'early_payment')->first();
            if ($baseRule) {
                $adjustment = [
                    'amount' => round($debtUSD * ($baseRule->discount_percentage / 100), 2),
                    'percentage' => $baseRule->discount_percentage,
                    'reason' => 'Forzado: ' . ($baseRule->description ?? 'Pronto Pago Base'),
                    'days' => $daysElapsed,
                    'rule_type' => 'early_payment',
                    'tag' => $baseRule->tag ?? null
                ];
            }
        }

        $this->sale_id = $sale_id;
        $this->customer_name = $customer;
        $this->debt = round($debtInPrimary, 2);
        $this->debt_usd = round($debtUSD, 2);

        // Check Permissions
        $canUpload = auth()->user()->can('payments.upload');
        $canPay = auth()->user()->can('payments.register_direct');
        
        $this->dispatch('initPayment', 
            total: $this->debt, 
            currency: 'USD', 
            customer: $this->customer_name, 
            allowPartial: true,
            adjustment: $adjustment,
            allowDiscounts: $allowDiscounts,
            usdDiscountPercent: $usdPaymentDiscountPercent,
            fixedUsdDiscountAmount: $fixedUsdDiscountAmount,
            canUpload: $canUpload,
            canPay: $canPay,
            customerId: $sale->customer->id ?? $sale->customer_id,
            walletBalance: $sale->customer->wallet_balance ?? 0,
            metadata: ['sale_id' => $sale_id]
        );
    }
    
    #[On('payment-uploaded')]
    public function handlePaymentUploaded($payments, $change, $changeDistribution, $metadata = [], $debitNotes = []) 
    {
         $this->processPayment($payments, 'pending', $metadata, $debitNotes);
    }

    #[On('payment-completed')]
    public function handlePaymentCompleted($payments, $change, $changeDistribution, $metadata = [], $debitNotes = [])
    {
        $this->processPayment($payments, 'approved', $metadata, $debitNotes);
    }

    public function initDebitNotePayment($note_id, $customer = null)
    {
        $note = \App\Models\DebitNote::find($note_id);
        if (!$note) {
            $this->dispatch('noty', msg: 'Nota de Débito no encontrada');
            return;
        }

        if (empty($customer)) {
            $customer = $note->customer->name ?? '';
        }

        $this->sale_id = null; // Clear sale id to avoid confusion

        $debtUSD = $note->amount / ($note->exchange_rate > 0 ? $note->exchange_rate : 1);
        
        $primaryCurrency = \App\Models\Currency::where('is_primary', true)->first();
        $debtInPrimary = $debtUSD * ($primaryCurrency ? $primaryCurrency->exchange_rate : 1);

        $this->dispatch('initPayment', 
            total: $debtInPrimary, 
            currency: 'USD', 
            customer: $customer, 
            allowPartial: true,
            adjustment: null,
            allowDiscounts: false,
            usdDiscountPercent: 0,
            fixedUsdDiscountAmount: 0,
            canUpload: auth()->user()->can('payments.upload'),
            canPay: auth()->user()->can('payments.register_direct'),
            customerId: $note->customer_id,
            walletBalance: $note->customer->wallet_balance ?? 0,
            metadata: ['debit_note_id' => $note_id]
        );
    }

    public function processPayment($payments, $status, $metadata = [], $debitNotes = [])
    {
        $saleId = $this->sale_id;
        $debitNoteId = $metadata['debit_note_id'] ?? null;
        $debitNote = $debitNoteId ? \App\Models\DebitNote::find($debitNoteId) : null;

        // Si la nota de débito tiene una factura asociada, vinculamos el pago también a esa factura
        if (!$saleId && $debitNote && $debitNote->sale_id) {
            $saleId = $debitNote->sale_id;
        }

        if (!$saleId && !$debitNoteId) {
            Log::warning("AccountsReceivableReport::processPayment - No target identified", ['sale_id' => $saleId, 'metadata' => $metadata]);
            return;
        }

        DB::beginTransaction();
        try {
            $sale = $saleId ? Sale::find($saleId) : null;
            
            $customerId = $sale ? $sale->customer_id : ($debitNote ? $debitNote->customer_id : null);
            
            if (!$customerId) throw new \Exception("Cliente no identificado");

            $primaryCurrency = \App\Models\Currency::where('is_primary', true)->first();
            
            // --- HANDLE MANUAL DEBIT NOTES ---
            foreach ($debitNotes as $dn) {
                $lastNote = \App\Models\DebitNote::latest('id')->first();
                $nextNumber = $lastNote ? $lastNote->id + 1 : 1;
                $debitNumber = 'ND-' . str_pad($nextNumber, 6, '0', STR_PAD_LEFT);

                \App\Models\DebitNote::create([
                    'debit_number' => $debitNumber,
                    'customer_id' => $customerId,
                    'user_id' => auth()->id(),
                    'sale_id' => $saleId,
                    'amount' => $dn['amount'],
                    'currency' => $dn['currency'] ?? ($primaryCurrency ? $primaryCurrency->code : 'USD'),
                    'exchange_rate' => $dn['exchange_rate'],
                    'concept' => $dn['reason'],
                    'status' => 'pending'
                ]);
            }
            
            foreach ($payments as $payment) {
                $amount = $payment['amount'];
                $currencyCode = $payment['currency'];
                $exchangeRate = $payment['exchange_rate'];

                if ($payment['method'] == 'credit_note') {
                    \App\Models\SaleReturn::create([
                        'sale_id' => $sale->id,
                        'customer_id' => $sale->customer_id,
                        'user_id' => auth()->id(),
                        'return_number' => 'NC-' . strtoupper(\Illuminate\Support\Str::random(6)),
                        'total_returned' => $payment['amount_in_invoice_currency'] ?? $amount,
                        'reason' => $payment['note'] ?? 'Nota de Crédito Manual',
                        'return_type' => 'manual',
                        'refund_method' => 'debt_reduction',
                        'collection_sheet_id' => $this->getOrCreateCollectionSheet(),
                        'status' => 'approved'
                    ]);
                    continue;
                }
                
                // Handle Zelle Record
                $zelleRecordId = null;
                if ($payment['method'] == 'zelle') {
                    // Check if Zelle record exists
                    $zelleRecord = \App\Models\ZelleRecord::where('sender_name', $payment['zelle_sender'])
                        ->where('zelle_date', $payment['zelle_date'])
                        ->where('amount', $payment['zelle_amount'])
                        ->first();

                    $amountUsed = $payment['amount'];

                    if ($zelleRecord) {
                        // Use existing record
                        $zelleRecord->remaining_balance -= $amountUsed;
                        if ($zelleRecord->remaining_balance < 0) $zelleRecord->remaining_balance = 0;
                        
                        $zelleRecord->status = $zelleRecord->remaining_balance <= 0.01 ? 'used' : 'partial';
                        $zelleRecord->save();
                        
                        $zelleRecordId = $zelleRecord->id;
                    } else {
                        // Create new record
                        $remaining = $payment['zelle_amount'] - $amountUsed;
                        
                        $zelleRecord = \App\Models\ZelleRecord::create([
                            'sender_name' => $payment['zelle_sender'],
                            'zelle_date' => $payment['zelle_date'],
                            'amount' => $payment['zelle_amount'],
                            'reference' => $payment['reference'] ?? null,
                            'image_path' => $payment['zelle_image'] ?? null,
                            'status' => $remaining <= 0.01 ? 'used' : 'partial',
                            'remaining_balance' => max(0, $remaining),
                            'customer_id' => $customerId,
                            'sale_id' => $sale ? $sale->id : null,
                            'debit_note_id' => $debitNote ? $debitNote->id : null,
                            'invoice_total' => $sale ? $sale->total : $amountUsed,
                            'payment_type' => $sale ? ($amountUsed >= ($sale->total - 0.01) ? 'full' : 'partial') : 'full'
                        ]);
                        
                        $zelleRecordId = $zelleRecord->id;
                    }
                }

                // Handle Bank Record (Abonos)
                $bankRecordId = null;
                $createdBankRecord = null;
                
                if ($payment['method'] == 'bank' && !empty($payment['bank_reference'])) {
                     try {
                        $createdBankRecord = \App\Models\BankRecord::create([
                            'bank_id' => $payment['bank_id'],
                            'amount' => $payment['amount'],
                            'reference' => $payment['bank_reference'],
                            'payment_date' => $payment['bank_date'] ?? now(),
                            'image_path' => $payment['bank_image'] ?? null,
                            'note' => $payment['bank_note'] ?? null,
                            'status' => 'used',
                            'remaining_balance' => 0,
                            'customer_id' => $customerId,
                            'sale_id' => $sale ? $sale->id : null,
                            'debit_note_id' => $debitNote ? $debitNote->id : null,
                        ]);
                        $bankRecordId = $createdBankRecord->id;
                     } catch (\Exception $e) {
                          // Log error but continue
                     }
                }

                // Use Trait for sheet
                $sheetId = $this->getOrCreateCollectionSheet();
                $sheet = \App\Models\CollectionSheet::find($sheetId);

                $payWay = $payment['method'] == 'bank' ? 'deposit' : $payment['method'];

                // Prevent accidental duplicate payment creation (e.g. double submission within 60s)
                $existingPayment = Payment::where(function($q) use ($saleId, $debitNoteId) {
                        if ($saleId) $q->where('sale_id', $saleId);
                        if ($debitNoteId) $q->orWhere('debit_note_id', $debitNoteId);
                    })
                    ->where('pay_way', $payWay)
                    ->where('amount', floatval($amount))
                    ->where('currency', $currencyCode)
                    ->when($zelleRecordId, fn($q) => $q->where('zelle_record_id', $zelleRecordId))
                    ->when(isset($payment['reference']) && !empty($payment['reference']), fn($q) => $q->where('deposit_number', $payment['reference']))
                    ->where('created_at', '>=', \Carbon\Carbon::now()->subSeconds(60))
                    ->first();

                if ($existingPayment) {
                    Log::warning("Duplicate payment prevented in AccountsReceivableReport", ['sale_id' => $saleId, 'debit_note_id' => $debitNoteId, 'amount' => $amount]);
                    continue;
                }

                $pay = Payment::create([
                    'user_id' => Auth()->user()->id,
                    'sale_id' => $saleId ?: null,
                    'debit_note_id' => $debitNoteId ?: null,
                    'amount' => floatval($amount),
                    'currency' => $currencyCode,
                    'exchange_rate' => $exchangeRate,
                    'primary_exchange_rate' => $primaryCurrency->exchange_rate,
                    'pay_way' => $payWay,
                    'type' => 'pay',
                    'status' => $status, // Add status
                    'bank' => $payment['bank_name'] ?? null,
                    'account_number' => $payment['account_number'] ?? null,
                    'deposit_number' => $payment['reference'] ?? null,
                    'phone_number' => $payment['phone'] ?? null,
                    'payment_date' => $payment['payment_date'] ?? $payment['bank_date'] ?? $payment['zelle_date'] ?? \Carbon\Carbon::now(),
                    'zelle_record_id' => $zelleRecordId,
                    'bank_record_id' => $bankRecordId, // Linked Bank Record
                    'collection_sheet_id' => $sheet->id,
                    // Track Discount/Surcharge
                    'discount_applied' => $payment['discount_amount'] ?? 0,
                    'discount_percentage' => $payment['discount_percentage'] ?? 0,
                    'discount_reason' => $payment['discount_reason'] ?? null,
                    'payment_days' => $payment['days_elapsed'] ?? 0,
                    'rule_type' => $payment['rule_type'] ?? null
                ]);

                // Update BankRecord with payment_id
                if ($createdBankRecord) {
                    $createdBankRecord->update(['payment_id' => $pay->id]);
                }

                // Standardized Rule: Only increment collection sheet total if APPROVED
                if ($status === 'approved') {
                    $amountUSD = $amount / ($exchangeRate > 0 ? $exchangeRate : 1);
                    $sheet->increment('total_amount', $amountUSD);
                }
            }

            // Only update sale totals if APPROVED
            if ($status === 'approved') {
                 if ($sale) $this->checkSaleSettlement($sale);
                 if ($debitNote) $debitNote->checkSettlement();
            }

            DB::commit();

            if ($status === 'approved') {
                $this->printPayment($pay->id ?? null); 
                $this->dispatch('noty', msg: 'PAGO REGISTRADO CON ÉXITO');
            } else {
                 $this->dispatch('noty', msg: 'PAGO SUBIDO. PENDIENTE DE APROBACIÓN.');
            }

            $this->dispatch('hide-modal-payment'); 
            
            $this->sale_id = null;
            $this->customer_name = null;
            $this->debt = null;
            $this->debt_usd = null;

        } catch (\Exception $th) {
            DB::rollBack();
            $this->dispatch('noty', msg: "Error al registrar el pago: {$th->getMessage()}");
        }
    }
    
    public function approvePayment(\App\Services\CashRegisterService $cashRegisterService, $paymentId)
    {
        if (!auth()->user()->can('payments.approve')) {
             $this->dispatch('noty', msg: 'NO TIENES PERMISO PARA APROBAR PAGOS');
             return;
        }

        try {
            DB::beginTransaction();
            $payment = Payment::find($paymentId);
            if ($payment && $payment->status === 'pending') {
                
                // 1. Record Cash Movement
                $activeRegister = $cashRegisterService->getActiveCashRegister(auth()->id());
                if (!$activeRegister) {
                    // Fallback to shared register if enabled
                    $config = \App\Models\Configuration::first();
                    if ($config && $config->enable_shared_cash_register) {
                        $activeRegister = \App\Models\CashRegister::where('status', 'open')->latest()->first();
                    }
                }

                if (!$activeRegister) {
                    throw new \Exception("NO HAY CAJA ABIERTA para recibir este pago. Abra una caja o active el modo compartido.");
                }

                if ($payment->debit_note_id) {
                    $cashRegisterService->recordDebitNoteMovement(
                        $activeRegister->id,
                        $payment->debit_note_id,
                        $payment->currency,
                        $payment->amount,
                        "Aprobación de pago #{$payment->id} (Nota Débito)"
                    );
                } else {
                    $cashRegisterService->recordSaleMovement(
                        $activeRegister->id,
                        $payment->sale_id,
                        'sale_payment',
                        $payment->currency,
                        $payment->amount,
                        "Aprobación de pago #{$payment->id} (Ref: {$payment->deposit_number})"
                    );
                }

                // 2. Handle Collection Sheet Transition
                $oldSheetId = $payment->collection_sheet_id;
                $currentSheetId = $this->getOrCreateCollectionSheet();
                $currentSheet = \App\Models\CollectionSheet::find($currentSheetId);

                // If moving from another sheet, decrement old one (safety - ONLY if it was already approved)
                if ($oldSheetId && $oldSheetId != $currentSheetId && $payment->status === 'approved') {
                    $oldSheet = \App\Models\CollectionSheet::find($oldSheetId);
                    if ($oldSheet) {
                        $amountUSD = $payment->amount / ($payment->exchange_rate > 0 ? $payment->exchange_rate : 1);
                        $oldSheet->decrement('total_amount', $amountUSD);
                    }
                }

                // Update to CURRENT collection sheet
                $payment->update([
                    'status' => 'approved',
                    'collection_sheet_id' => $currentSheetId
                ]);

                if ($payment->debit_note_id) {
                    $payment->debitNote->checkSettlement();
                }

                if ($payment->sale_id) {
                    $this->checkSaleSettlement($payment->sale);
                }

                // Increment TODAY'S sheet total (always, as it is now approved)
                $amountUSD = $payment->amount / ($payment->exchange_rate > 0 ? $payment->exchange_rate : 1);
                $currentSheet->increment('total_amount', $amountUSD);
                
                $sale = $payment->sale_id ? Sale::find($payment->sale_id) : null;
                if ($sale) {
                    $this->checkSaleSettlement($sale);
                }
                
                DB::commit();
                $this->dispatch('noty', msg: 'PAGO APROBADO Y REGISTRADO EN CAJA');
                
                // Refresh list if viewing history
                if ($sale && $this->pays && count($this->pays) > 0 && ($this->pays[0]->sale_id ?? null) == $sale->id) {
                     $this->pays = $sale->payments; 
                }
            }
        } catch (\Exception $e) {
            DB::rollBack();
            $this->dispatch('noty', msg: 'Error al aprobar: ' . $e->getMessage());
        }
    }


    public function rejectPayment($paymentId, $reason)
    {
        if (!auth()->user()->can('payments.approve')) {
             $this->dispatch('noty', msg: 'NO TIENES PERMISO PARA RECHAZAR PAGOS');
             return;
        }

        try {
            $payment = Payment::find($paymentId);
            if ($payment && $payment->status === 'pending') {
                $payment->update([
                    'status' => 'rejected',
                    'rejection_reason' => $reason
                ]);
                
                $this->dispatch('noty', msg: 'PAGO RECHAZADO CORRECTAMENTE');
                
                // Refresh list
                $sale = Sale::find($payment->sale_id);
                if ($this->pays && count($this->pays) > 0 && $this->pays[0]->sale_id == $sale->id) {
                     $this->pays = $sale->payments; 
                }
            }
        } catch (\Exception $e) {
            $this->dispatch('noty', msg: 'Error al rechazar: ' . $e->getMessage());
        }
    }

    public function voidPayment($paymentId, $reason)
    {
        $payment = Payment::find($paymentId);
        
        if (!$payment) return;

        $isToday = Carbon::parse($payment->payment_date ?? $payment->created_at)->isToday();
        
        // Permission check
        if ($isToday) {
            if (!auth()->user()->can('payments.void_today')) {
                $this->dispatch('noty', msg: 'NO TIENES PERMISO PARA ANULAR PAGOS DEL DÍA');
                return;
            }
        } else {
            if (!auth()->user()->can('payments.void_anytime')) {
                $this->dispatch('noty', msg: 'NO TIENES PERMISO PARA ANULAR PAGOS DE FECHAS ANTERIORES');
                return;
            }
        }

        try {
            DB::beginTransaction();

            // Revert Zelle Record if exists
            if ($payment->zelle_record_id) {
                $zelle = \App\Models\ZelleRecord::find($payment->zelle_record_id);
                if ($zelle) {
                    $zelle->remaining_balance += $payment->amount;
                    if ($zelle->remaining_balance > $zelle->amount) $zelle->remaining_balance = $zelle->amount;
                    $zelle->status = ($zelle->remaining_balance >= ($zelle->amount - 0.01)) ? 'unused' : 'partial';
                    $zelle->save();
                }
            }
            
            // Bank Record - Restore balance
            if ($payment->bank_record_id) {
                $bankRec = \App\Models\BankRecord::find($payment->bank_record_id);
                if ($bankRec) {
                    $bankRec->remaining_balance += $payment->amount;
                    if ($bankRec->remaining_balance > $bankRec->amount) $bankRec->remaining_balance = $bankRec->amount;
                    $bankRec->status = ($bankRec->remaining_balance >= ($bankRec->amount - 0.01)) ? 'unused' : 'partial';
                    $bankRec->save();
                }
            }

            // Revert Collection Sheet total if it was APPROVED (BEFORE status update)
            if ($payment->collection_sheet_id && $payment->status === 'approved') {
                $sheet = \App\Models\CollectionSheet::find($payment->collection_sheet_id);
                if ($sheet) {
                    $amountUSD = $payment->amount / ($payment->exchange_rate > 0 ? $payment->exchange_rate : 1);
                    $sheet->decrement('total_amount', $amountUSD);
                }
            }

            // Update status to voided
            $payment->update([
                'status' => 'voided',
                'rejection_reason' => $reason
            ]);

            // Restore sale status if it was paid
            $sale = Sale::find($payment->sale_id);
            if ($sale) {
                 $this->checkSaleSettlement($sale);
            }

            DB::commit();
            $this->dispatch('noty', msg: 'Pago anulado correctamente');
            
            if ($sale && $this->pays && count($this->pays) > 0 && $this->pays[0]->sale_id == $sale->id) {
                $this->pays = $sale->payments; 
            }
        } catch (\Exception $e) {
            DB::rollBack();
            $this->dispatch('noty', msg: 'Error al anular: ' . $e->getMessage());
        }
    }

    public function voidDebitNote($id, $reason)
    {
        $dn = \App\Models\DebitNote::find($id);
        if (!$dn) return;

        // Permission check
        if (!auth()->user()->can('payments.void_anytime')) {
             $this->dispatch('noty', msg: 'NO TIENES PERMISO PARA ANULAR NOTAS DE DÉBITO');
             return;
        }

        try {
            DB::beginTransaction();

            $dn->update([
                'status' => 'voided',
                'concept' => $dn->concept . ' (ANULADA: ' . $reason . ')'
            ]);

            // Restore sale status
            if ($dn->sale_id) {
                $sale = Sale::find($dn->sale_id);
                if ($sale) {
                    $this->checkSaleSettlement($sale);
                }
            }

            DB::commit();
            $this->dispatch('noty', msg: 'Nota de Débito anulada correctamente');
            
            // Refresh history if open
            if (isset($this->history_sale_id) && $this->history_sale_id) {
                $this->historyPayments($this->history_sale_id);
            }

        } catch (\Exception $e) {
            DB::rollBack();
            $this->dispatch('noty', msg: 'Error: ' . $e->getMessage());
        }
    }



    public function deletePayment($paymentId)
    {
        if (!auth()->user()->can('payments.delete')) {
            $this->dispatch('noty', msg: 'NO TIENES PERMISO PARA ELIMINAR PAGOS');
            return;
        }

        try {
            DB::beginTransaction();
            $payment = Payment::find($paymentId);
            
            if ($payment && ($payment->status === 'pending' || $payment->status === 'rejected')) {
                
                // Revert Zelle Record if exists
                $zelleRecordId = $payment->zelle_record_id;
                if ($zelleRecordId) {
                    $zelle = \App\Models\ZelleRecord::find($zelleRecordId);
                    if ($zelle) {
                         $amountToRestore = $payment->amount; 
                         $zelle->remaining_balance += $amountToRestore;
                         if ($zelle->remaining_balance > $zelle->amount) $zelle->remaining_balance = $zelle->amount;
                         
                         $zelle->status = ($zelle->remaining_balance >= ($zelle->amount - 0.01)) ? 'unused' : 'partial';
                         $zelle->save();
                    }
                }
                
                // Bank Record - Restore balance
                $bankRecordId = $payment->bank_record_id;
                if ($bankRecordId) {
                    $bankRec = \App\Models\BankRecord::find($bankRecordId);
                    if ($bankRec) {
                        $bankRec->remaining_balance += $payment->amount; // Restaurar saldo
                        if ($bankRec->remaining_balance > $bankRec->amount) $bankRec->remaining_balance = $bankRec->amount;
                        $bankRec->status = ($bankRec->remaining_balance >= ($bankRec->amount - 0.01)) ? 'unused' : 'partial';
                        $bankRec->save();
                    }
                }

                // Revert Collection Sheet total if it was APPROVED
                if ($payment->collection_sheet_id && $payment->status === 'approved') {
                    $sheet = \App\Models\CollectionSheet::find($payment->collection_sheet_id);
                    if ($sheet) {
                        $amountUSD = $payment->amount / ($payment->exchange_rate > 0 ? $payment->exchange_rate : 1);
                        $sheet->decrement('total_amount', $amountUSD);
                    }
                }

                $payment->delete(); // Delete payment first
                
                // Final cleanup: Delete records if they have NO more payments
                if ($zelleRecordId) {
                    if (!\App\Models\Payment::where('zelle_record_id', $zelleRecordId)->exists()) {
                        \App\Models\ZelleRecord::destroy($zelleRecordId);
                    }
                }

                if ($bankRecordId) {
                    if (!\App\Models\Payment::where('bank_record_id', $bankRecordId)->exists()) {
                        \App\Models\BankRecord::destroy($bankRecordId);
                    }
                }
                
                DB::commit();
                $this->dispatch('noty', msg: 'Pago eliminado correctamente');
                
                $sale = Sale::find($payment->sale_id);
                if ($this->pays && count($this->pays) > 0 && $this->pays[0]->sale_id == $sale->id) {
                     $this->pays = $sale->payments; 
                }
            } else {
                 $this->dispatch('noty', msg: 'No se puede eliminar este pago (Estado incorrecto)');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            $this->dispatch('noty', msg: 'Error al eliminar: ' . $e->getMessage());
        }
    }



    public function checkSaleSettlement($sale) {
        $sale->checkSettlement();
    }

    public function editPayment($paymentId)
    {
        if (!auth()->user()->can('payments.approve')) {
             $this->dispatch('noty', msg: 'NO TIENES PERMISO PARA EDITAR PAGOS');
             return;
        }
        
        $payment = Payment::find($paymentId);
        if ($payment && $payment->status === 'pending') {
            $this->editingPaymentId = $payment->id;
            $this->editPaymentAmount = number_format($payment->amount, 2, '.', '');
            $this->editPaymentRate = number_format($payment->exchange_rate, 4, '.', '');
            // Strip trailing zeros after the decimal point to show neat numbers (e.g. 420.0000 -> 420)
            if (strpos($this->editPaymentRate, '.') !== false) {
                $this->editPaymentRate = rtrim(rtrim($this->editPaymentRate, '0'), '.');
            }
            $this->editPaymentComment = $payment->modification_comment ?? '';
            $this->editPaymentRef = $payment->deposit_number ?? $payment->reference_number ?? ($payment->zelleRecord->reference ?? $payment->bankRecord->reference ?? '');
            $this->editPaymentDate = $payment->payment_date ? \Carbon\Carbon::parse($payment->payment_date)->format('Y-m-d') : date('Y-m-d');
            
            // Re-calculate potential discounts 
            $this->editApplyEarlyDiscount = false;
            $this->editApplyUsdDiscount = false;
            $this->editEarlyDiscountAmount = 0;
            $this->editUsdDiscountAmount = 0;
            $this->editEarlyDiscountPercent = 0;
            $this->editUsdDiscountPercent = 0;
            $this->editEarlyDiscountReason = '';
            $this->editUsdDiscountReason = '';
            $this->editSaleTotal = 0;
            $this->editSalePaid = 0;
            $this->editSaleDebt = 0;

            $sale = Sale::find($payment->sale_id);
            if ($sale) {
                // Calculate debt overview
                $this->editSaleTotal = $sale->total_usd > 0 ? $sale->total_usd : ($sale->total / ($sale->primary_exchange_rate > 0 ? $sale->primary_exchange_rate : 1));
                
                $totalPaidUSD = $sale->payments->whereNotIn('status', ['pending', 'rejected'])->sum(function($p) {
                    $rate = $p->exchange_rate > 0 ? $p->exchange_rate : 1;
                    return ($p->amount / $rate) + ($p->discount_applied ?? 0);
                });
                $initialPaidUSD = $sale->paymentDetails->sum(function($detail) {
                    $rate = $detail->exchange_rate > 0 ? $detail->exchange_rate : 1;
                    return $detail->amount / $rate;
                });
                $totalReturnsOrig = $sale->returns->where('refund_method', 'debt_reduction')->sum('total_returned');
                $totalReturnsUSD = $totalReturnsOrig / ($sale->primary_exchange_rate > 0 ? $sale->primary_exchange_rate : 1);
                
                $this->editSalePaid = $totalPaidUSD + $initialPaidUSD + $totalReturnsUSD;
                $this->editSaleDebt = max(0, $this->editSaleTotal - $this->editSalePaid);

                // Parse snapshot
                $parsedSnapshot = \App\Services\CreditConfigService::parseCreditSnapshot($sale->credit_rules_snapshot);
                $rules = $parsedSnapshot['discount_rules'];
                $snapshotUsdDiscount = $parsedSnapshot['usd_payment_discount'];

                if (empty($sale->credit_rules_snapshot)) {
                    $creditConfig = \App\Services\CreditConfigService::getCreditConfig($sale->customer, $sale->customer->seller);
                    $rules = $creditConfig['discount_rules'];
                    $snapshotUsdDiscount = null;
                }

                $daysElapsed = \Carbon\Carbon::parse($sale->created_at)->diffInDays(\Carbon\Carbon::parse($payment->payment_date ?? $payment->created_at));
                $adjustment = \App\Services\CreditConfigService::calculateDiscount($sale->total_usd, $daysElapsed, $rules);

                if ($adjustment) {
                    $this->editEarlyDiscountAmount = $adjustment['amount'];
                    $this->editEarlyDiscountPercent = $adjustment['percentage'];
                    $this->editEarlyDiscountReason = $adjustment['reason'];
                } elseif (auth()->user()->can('payments.force_discounts')) {
                    $baseRule = $rules->where('rule_type', 'early_payment')->first();
                    if ($baseRule) {
                        $this->editEarlyDiscountPercent = $baseRule->discount_percentage;
                        $this->editEarlyDiscountAmount = round($sale->total_usd * ($baseRule->discount_percentage / 100), 2);
                        $this->editEarlyDiscountReason = 'Forzado: ' . ($baseRule->description ?? 'Pronto Pago Base');
                    }
                }

                $usdPaymentDiscountPercent = 0;
                $isUsdForced = false;
                
                if ($sale->is_foreign_sale) {
                    $hasVedHistory = $sale->payments()->whereIn('currency', ['VED', 'VES'])->exists();
                    
                    if (!$hasVedHistory || auth()->user()->can('payments.force_discounts')) {
                        if ($snapshotUsdDiscount !== null) {
                            $usdPaymentDiscountPercent = $snapshotUsdDiscount;
                        } else {
                            $config = \App\Services\CreditConfigService::getCreditConfig($sale->customer, $sale->customer->seller);
                            $usdPaymentDiscountPercent = $config['usd_payment_discount'] ?? 0;
                        }
                        
                        if ($hasVedHistory) {
                            $isUsdForced = true;
                        }
                    }

                    if ($usdPaymentDiscountPercent > 0) {
                        $this->editUsdDiscountAmount = round($sale->total_usd * ($usdPaymentDiscountPercent / 100), 2);
                        $this->editUsdDiscountPercent = $usdPaymentDiscountPercent;
                        $this->editUsdDiscountReason = 'Descuento Pago Divisa' . ($isUsdForced ? ' (Forzado)' : '');
                    }
                }

                // Check BD status
                $ruleType = $payment->rule_type ?? '';
                if (in_array($ruleType, ['early_payment', 'combined'])) {
                    $this->editApplyEarlyDiscount = true;
                }
                if (in_array($ruleType, ['usd_payment', 'combined'])) {
                    $this->editApplyUsdDiscount = true;
                }
                if (empty($ruleType) && $payment->discount_applied > 0) {
                    $this->editApplyEarlyDiscount = true; // Fallback
                }
            }
            
            $this->dispatch('show-edit-payment-modal');
        }
    }

    public function updatePayment()
    {
        if (!auth()->user()->can('payments.approve')) {
             $this->dispatch('noty', msg: 'NO TIENES PERMISO PARA EDITAR PAGOS');
             return;
        }
        
        $this->validate([
            'editPaymentAmount' => 'required|numeric|min:0.01',
            'editPaymentRate' => 'required|numeric|min:0.01',
            'editPaymentRef' => 'required|string',
            'editPaymentDate' => 'required|date',
            'editPaymentComment' => 'nullable|string',
        ]);

        try {
            DB::beginTransaction();
            $payment = Payment::find($this->editingPaymentId);
            
            if ($payment && $payment->status === 'pending') {
                $payment->amount = $this->editPaymentAmount;
                $payment->exchange_rate = $this->editPaymentRate;
                $payment->deposit_number = $this->editPaymentRef;
                $payment->payment_date = $this->editPaymentDate;
                $payment->modification_comment = $this->editPaymentComment;
                
                // Recalculate and apply discount fields
                $totalDiscount = 0;
                $totalPercent = 0;
                $reason = '';
                $ruleType = '';
                
                if ($this->editApplyEarlyDiscount) {
                     $totalDiscount += $this->editEarlyDiscountAmount;
                     $totalPercent += $this->editEarlyDiscountPercent;
                     $reason = $this->editEarlyDiscountReason;
                     $ruleType = 'early_payment';
                }
                
                if ($this->editApplyUsdDiscount) {
                     $totalDiscount += $this->editUsdDiscountAmount;
                     $totalPercent += $this->editUsdDiscountPercent;
                     if ($reason) $reason .= ' + ';
                     $reason .= $this->editUsdDiscountReason;
                     $ruleType = $ruleType ? 'combined' : 'usd_payment';
                }

                $payment->discount_applied = $totalDiscount;
                $payment->discount_percentage = $totalPercent;
                $payment->discount_reason = $reason;
                $payment->rule_type = $ruleType;
                
                $payment->save();

                // Update underlying BankRecord or ZelleRecord
                if ($payment->bank_record_id) {
                    $bankRecord = \App\Models\BankRecord::find($payment->bank_record_id);
                    if ($bankRecord) {
                        $bankRecord->amount = $this->editPaymentAmount;
                        $bankRecord->reference = $this->editPaymentRef;
                        $bankRecord->payment_date = $this->editPaymentDate;
                        $bankRecord->save();
                    }
                } elseif ($payment->zelle_record_id) {
                    $zelleRecord = \App\Models\ZelleRecord::find($payment->zelle_record_id);
                    if ($zelleRecord) {
                        $zelleRecord->amount = $this->editPaymentAmount;
                        $zelleRecord->reference = $this->editPaymentRef;
                        $zelleRecord->zelle_date = $this->editPaymentDate;
                        $zelleRecord->save();
                    }
                }

                DB::commit();
                $this->dispatch('noty', msg: 'Pago pendiente actualizado exitosamente');
                $this->dispatch('hide-edit-payment-modal');
                
                // Refresh list
                $sale = Sale::find($payment->sale_id);
                if ($this->pays && count($this->pays) > 0 && $this->pays[0]->sale_id == $sale->id) {
                     $this->pays = $sale->payments; 
                }
            } else {
                $this->dispatch('noty', msg: 'No se puede editar este pago (debe estar pendiente)');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            $this->dispatch('noty', msg: 'Error al actualizar: ' . $e->getMessage());
        }
    }

    function cancelPay()
    {
        $this->sale_id = null;
        $this->customer_name = null;
        $this->debt = null;
        $this->debt_usd = null;
        $this->seller_name = null;

        $this->editingPaymentId = null;
        $this->editPaymentRef = '';
        $this->editPaymentAmount = 0;
        $this->editPaymentDate = date('Y-m-d');
        $this->editPaymentRate = 1;
        $this->editPaymentComment = '';
    }
    function historyPayments($sale_id)
    {
        $sale = Sale::with(['payments', 'returns', 'debitNotes'])->find($sale_id);
        if ($sale) {
            $this->history_sale_id = $sale->id;
            $this->pays = $sale->payments;
            $this->dispatch('show-payhistory');
        }
    }

    public function resetCreditSnapshot($saleId)
    {
        if (!auth()->user()->can('sales.reset_credit_snapshot')) {
             $this->dispatch('noty', msg: 'NO TIENES PERMISO PARA ACTUALIZAR LAS REGLAS DE CRÉDITO');
             return;
        }

        $sale = Sale::find($saleId);
        if ($sale) {
            $creditConfig = \App\Services\CreditConfigService::getCreditConfig($sale->customer, $sale->customer->seller);
            
            $snapshotToSave = [
                'discount_rules' => $creditConfig['discount_rules']->toArray(),
                'usd_payment_discount' => $creditConfig['usd_payment_discount'],
                'usd_payment_discount_tag' => $creditConfig['usd_payment_discount_tag']
            ];

            $sale->update(['credit_rules_snapshot' => $snapshotToSave]);
            $this->dispatch('noty', msg: 'REGLAS DE CRÉDITO ACTUALIZADAS Y FIJADAS A LA CONFIGURACIÓN DEL CLIENTE (INMUTABLE)');
            // Also refresh the history view by passing the sale ID (this method expects the ID)
            $this->historyPayments($sale->id);
        }
    }

    function printHistory()
    {
        if (empty($this->pays) || count($this->pays) == 0) {
            $this->dispatch('noty', msg: 'NO HAY PAGOS PARA IMPRIMIR');
            return;
        }

        $saleId = $this->pays[0]->sale_id;
        $this->printPaymentHistory($saleId);
        $this->dispatch('noty', msg: 'IMPRIMIENDO HISTORIAL DE PAGOS...');
    }

    function printReceipt($payment_id)
    {
        $this->printPayment($payment_id);
        $this->dispatch('noty', msg: 'IMPRIMIENDO RECIBO DE PAGO...');
    }

    public function generatePaymentHistoryPdf($saleId)
    {
        $sale = Sale::with(['customer', 'payments.zelleRecord', 'payments.bankRecord.bank', 'user'])->find($saleId);
        if (!$sale) {
             $this->dispatch('noty', msg: 'Venta no encontrada');
             return;
        }
        
        $config = \App\Models\Configuration::first();
        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('reports.payment-history-pdf', ['sale' => $sale, 'config' => $config]);
        
        return response()->streamDownload(function () use ($pdf) {
            echo $pdf->output();
        }, 'Historial_Pagos_Factura_' . $sale->id . '_' . date('YmdHis') . '.pdf');
    }

    public function approveReturn($returnId)
    {
        if (!auth()->user()->can('sales.approve_return') && !auth()->user()->hasRole('Admin')) {
            $this->dispatch('noty', msg: 'No tienes permiso para aprobar devoluciones', type: 'error');
            return;
        }

        DB::beginTransaction();
        try {
            $saleReturn = SaleReturn::with('details', 'sale')->findOrFail($returnId);
            
            if ($saleReturn->status !== 'pending') {
                $this->dispatch('noty', msg: 'Esta devolución ya fue procesada', type: 'warning');
                return;
            }

            $saleReturn->update([
                'status' => 'approved',
                'approved_by' => auth()->id(),
                'approved_at' => Carbon::now()
            ]);

            $this->executeReturnEffects($saleReturn);

            DB::commit();
            $this->dispatch('noty', msg: 'Devolución aprobada con éxito', type: 'success');
            
            // Refresh history view
            $this->historyPayments($saleReturn->sale_id);
            // Refresh main list
            $this->render();
            
        } catch (\Exception $e) {
            DB::rollBack();
            $this->dispatch('noty', msg: 'Error al aprobar: ' . $e->getMessage(), type: 'error');
        }
    }

    public function rejectReturn($returnId)
    {
        if (!auth()->user()->can('sales.approve_return') && !auth()->user()->hasRole('Admin')) {
            $this->dispatch('noty', msg: 'No tienes permiso para rechazar devoluciones', type: 'error');
            return;
        }

        try {
            $saleReturn = SaleReturn::findOrFail($returnId);
            $saleReturn->update([
                'status' => 'rejected',
                'approved_by' => auth()->id(),
                'approved_at' => Carbon::now()
            ]);

            $this->dispatch('noty', msg: 'Devolución rechazada', type: 'info');
            $this->historyPayments($saleReturn->sale_id);
        } catch (\Exception $e) {
            $this->dispatch('noty', msg: 'Error al rechazar: ' . $e->getMessage(), type: 'error');
        }
    }

    protected function executeReturnEffects(SaleReturn $saleReturn)
    {
        // Adjust Stock
        foreach ($saleReturn->details as $item) {
            if ($item->product_id) {
                $targetWarehouseId = null;
                $saleDetail = SaleDetail::find($item->sale_detail_id);
                
                if ($item->stock_action === 'returned_to_stock') {
                    if ($saleDetail) {
                         // RESTORE PRODUCT ITEM (BOBINAS/REELS)
                        $meta = json_decode($saleDetail->metadata, true);
                        if ($meta && isset($meta['product_item_id'])) {
                            $pi = \App\Models\ProductItem::find($meta['product_item_id']);
                            if ($pi) {
                                $pi->status = 'available';
                                $pi->save();
                            }
                        }

                        if ($saleDetail->warehouse_id) {
                            $targetWarehouseId = $saleDetail->warehouse_id;
                        }
                    }
                }
                
                if ($targetWarehouseId) {
                    $productWarehouse = ProductWarehouse::firstOrCreate(
                        ['product_id' => $item->product_id, 'warehouse_id' => $targetWarehouseId],
                        ['stock_qty' => 0]
                    );
                    $productWarehouse->stock_qty += $item->quantity_returned;
                    $productWarehouse->save();

                    // Update global product stock
                    if ($item->product) {
                        $item->product->increment('stock_qty', $item->quantity_returned);
                    }
                }
            }
        }

        // Handle Money Logic
        if ($saleReturn->refund_method === 'wallet' && $saleReturn->customer_id) {
            $customer = \App\Models\Customer::find($saleReturn->customer_id);
            $customer->wallet_balance += $saleReturn->total_returned;
            $customer->save();
        } 
        elseif ($saleReturn->refund_method === 'cash' && $saleReturn->cash_register_id) {
            \App\Models\CashMovement::create([
                'cash_register_id' => $saleReturn->cash_register_id,
                'user_id' => auth()->id(),
                'type' => 'expense',
                'amount' => $saleReturn->total_returned,
                'concept' => 'Devolución Factura #' . ($saleReturn->sale->invoice_number ?? $saleReturn->sale_id),
            ]);
        }
        
        if ($saleReturn->refund_method === 'debt_reduction') {
            $saleReturn->sale->checkSettlement();
        }
    }
}
