<?php

namespace App\Livewire\Cargos;

use Livewire\Component;
use Livewire\Attributes\Layout;

class CreateCargo extends Component
{
    use \Livewire\WithPagination;

    public $warehouse_id;
    public $motive;
    public $authorized_by;
    public $date;
    public $primaryVat = 0;
    public $canApproveCargo = false;
    public $canCreateCargo = false;
    
    public $search;
    public $searchResults = [];
    public $cart = [];
    public $selectedIndex = -1;
    
    public $warehouses = [];
    public $comments;

    public $cargo_id = null;

    public function mount($cargo = null)
    {
        $this->date = now()->format('Y-m-d\TH:i');

        // Cache Permissions
        $user = auth()->user();
        $this->canApproveCargo = $user->can('adjustments.approve_cargo');
        $this->canCreateCargo = $user->can('adjustments.create_cargo');

        // Cache Configuration
        $config = \App\Services\ConfigurationService::getConfig();
        $this->primaryVat = $config?->vat ?? 0;

        $this->warehouses = \App\Models\Warehouse::where('is_active', 1)->get();
        // Default warehouse if exists
        $this->warehouse_id = $this->warehouses->first()->id ?? null;

        // If editing an existing cargo (standard Laragon binding)
        if ($cargo) {
            $cargoObj = \App\Models\Cargo::with('details.product')->find($cargo);
            if ($cargoObj && $cargoObj->status == 'pending') {
                $this->cargo_id = $cargoObj->id;
                $this->warehouse_id = $cargoObj->warehouse_id;
                $this->motive = $cargoObj->motive;
                $this->authorized_by = $cargoObj->authorized_by;
                $this->comments = $cargoObj->comments;
                $this->date = $cargoObj->date->format('Y-m-d\TH:i');

                // Pre-fill cart
                foreach ($cargoObj->details as $item) {
                    if ($item->product) {
                        $this->cart['detail_' . $item->id] = [
                            'id' => $item->product_id,
                            'name' => $item->product->name,
                            'sku' => $item->product->sku,
                            'cost' => (float)$item->cost,
                            'quantity' => (float)$item->quantity,
                            'is_variable' => (bool)$item->product->is_variable_quantity,
                            'items' => $item->items_json ? json_decode($item->items_json, true) : []
                        ];
                    }
                }
            }
        }

        // If cloning from a clone_id query parameter
        if (request()->has('clone_id')) {
            $this->loadFromCargo(request('clone_id'));
        }
    }

    public function loadFromCargo($id)
    {
        $cargoObj = \App\Models\Cargo::with('details.product')->find($id);
        if (!$cargoObj) {
            $this->dispatch('noty', msg: "CARGO #$id NO ENCONTRADO", type: 'error');
            return;
        }

        $this->warehouse_id = $cargoObj->warehouse_id;
        $this->motive = $cargoObj->motive;
        $this->authorized_by = $cargoObj->authorized_by;
        $this->comments = $cargoObj->comments;
        
        // We do NOT set $this->cargo_id because we want to create a NEW one.
        
        $this->cart = []; // Clear current cart before cloning
        foreach ($cargoObj->details as $item) {
            if ($item->product) {
                $this->cart['detail_' . $item->id] = [
                    'id' => $item->product_id,
                    'name' => $item->product->name,
                    'sku' => $item->product->sku,
                    'cost' => (float)$item->cost,
                    'quantity' => (float)$item->quantity,
                    'is_variable' => (bool)$item->product->is_variable_quantity,
                    'items' => $item->items_json ? json_decode($item->items_json, true) : []
                ];
            }
        }
        
        $this->dispatch('noty', msg: "CARGO #$id CLONADO CON ÉXITO");
    }

    public function processCloningCode($code)
    {
        $code = strtoupper(trim($code));
        
        // Flexible Regex for Cargo/Entrada/Ajuste
        if (preg_match('/^(CARGO|ENTRADA|AJUSTE)[^0-9]*([0-9]+)$/i', $code, $matches)) {
            $id = $matches[2];
            $this->loadFromCargo($id);
            $this->search = '';
        }
    }

    public function updatedSearch()
    {
        $search = trim($this->search);
        $this->selectedIndex = -1;
        
        if (strlen($search) > 1) {
            $query = \App\Models\Product::query();
            
            // Tokenize search terms for multi-word search (inverted words support)
            $tokens = explode(' ', $search);
            
            foreach ($tokens as $token) {
                if (!empty($token)) {
                    $query->where(function($q) use ($token) {
                        $q->where('name', 'like', "%{$token}%")
                          ->orWhere('sku', 'like', "%{$token}%")
                          ->orWhereHas('category', function ($subQuery) use ($token) {
                              $subQuery->where('name', 'like', "%{$token}%");
                          });
                    });
                }
            }
            
            $this->searchResults = $query->take(10)->get();
        } else {
            $this->searchResults = [];
        }
    }

    public function selectProduct($index)
    {
        if ($index >= 0 && isset($this->searchResults[$index])) {
            $this->addToCart($this->searchResults[$index]->id);
        } elseif (count($this->searchResults) > 0) {
            // If nothing selected but Enter pressed, add the first one
            $this->addToCart($this->searchResults[0]->id);
        }
    }

    public function keyDown($key)
    {
        if ($key === 'ArrowDown') {
            $this->selectedIndex = min(count($this->searchResults) - 1, $this->selectedIndex + 1);
        } elseif ($key === 'ArrowUp') {
            $this->selectedIndex = max(-1, $this->selectedIndex - 1);
        } elseif ($key === 'Enter') {
            $this->selectProduct($this->selectedIndex);
        }
    }

    // Variable Item Inputs
    public $vw_weight, $vw_color, $vw_batch, $current_cart_key;

    public function addToCart($productId)
    {
        $product = \App\Models\Product::find($productId);
        if (!$product) return;

        // Find if there is an existing cart item for this product
        $existingKey = null;
        foreach ($this->cart as $key => $item) {
            if ($item['id'] == $productId) {
                $existingKey = $key;
                break;
            }
        }

        if ($existingKey !== null) {
            if (!$product->is_variable_quantity) {
                 $this->cart[$existingKey]['quantity'] = (float)$this->cart[$existingKey]['quantity'] + 1;
            }
        } else {
            $newKey = 'new_' . uniqid();
            $this->cart[$newKey] = [
                'id' => $product->id,
                'name' => $product->name,
                'sku' => $product->sku,
                'cost' => (float)($product->cost ?? 0),
                'quantity' => $product->is_variable_quantity ? 0 : 1,
                'is_variable' => (bool)$product->is_variable_quantity,
                'items' => [] 
            ];
        }
        
        $this->search = '';
        $this->searchResults = [];
    }
    
    public function openVariableModal($cartKey)
    {
        $this->current_cart_key = $cartKey;
        $this->vw_weight = '';
        $this->vw_color = '';
        $this->vw_batch = '';
        $this->dispatch('show-variable-modal');
    }

    public function addVariableItem()
    {
        $this->validate([
            'vw_weight' => 'required|numeric|min:0.01',
            'vw_color' => 'nullable|string|max:50',
            'vw_batch' => 'nullable|string|max:50'
        ]);

        if (isset($this->cart[$this->current_cart_key])) {
            $this->cart[$this->current_cart_key]['items'][] = [
                'weight' => (float)$this->vw_weight,
                'color' => $this->vw_color,
                'batch' => $this->vw_batch
            ];
            
            // Recalculate total weight/quantity
            $totalWeight = collect($this->cart[$this->current_cart_key]['items'])->sum('weight');
            $this->cart[$this->current_cart_key]['quantity'] = (float)$totalWeight;
        }

        $this->reset(['vw_weight', 'vw_color', 'vw_batch']);
        $this->dispatch('noty', msg: 'Item agregado a la lista');
        $this->dispatch('focus-weight');
    }

    public function removeVariableItem($cartKey, $index)
    {
        if (isset($this->cart[$cartKey]['items'][$index])) {
            unset($this->cart[$cartKey]['items'][$index]);
            $this->cart[$cartKey]['items'] = array_values($this->cart[$cartKey]['items']);
            
            $totalWeight = collect($this->cart[$cartKey]['items'])->sum('weight');
            $this->cart[$cartKey]['quantity'] = (float)$totalWeight;
        }
    }

    public function updateQuantity($cartKey, $cant)
    {
        if (isset($this->cart[$cartKey])) {
            $this->cart[$cartKey]['quantity'] = is_numeric($cant) ? (float)$cant : 0;
        }
    }

    public function removeFromCart($cartKey)
    {
        unset($this->cart[$cartKey]);
    }


    public function save()
    {
        $this->validate([
            'warehouse_id' => 'required|exists:warehouses,id',
            'date' => 'required|date',
            'motive' => 'required|string|max:255',
            'authorized_by' => 'required|string|max:255',
            'cart' => 'required|array|min:1'
        ]);

        // Validate Variable Items and Decimals
        foreach ($this->cart as $item) {
            $product = \App\Models\Product::find($item['id']);
            
            if ($product && !$product->allow_decimal) {
                if (floor($item['quantity']) != $item['quantity']) {
                    $this->addError("cart.{$item['id']}.quantity", "El producto {$product->name} no permite decimales.");
                    $this->dispatch('noty', msg: "El producto {$product->name} no permite cantidades decimales.", type: 'error');
                    return;
                }
            }

            if ($item['is_variable'] && empty($item['items'])) {
                $this->addError("cart", "El producto {$item['name']} requiere items.");
                $this->dispatch('noty', msg: "Faltan items en producto {$item['name']}", type: 'error');
                return;
            }
        }

        try {
            \Illuminate\Support\Facades\DB::beginTransaction();

            if ($this->cargo_id) {
                // Update existing cargo
                $cargo = \App\Models\Cargo::find($this->cargo_id);
                $cargo->update([
                    'warehouse_id' => $this->warehouse_id,
                    'user_id' => auth()->id(),
                    'authorized_by' => $this->authorized_by,
                    'motive' => $this->motive,
                    'date' => $this->date,
                    'comments' => $this->comments,
                ]);

                // Limpiar detalles anteriores
                \App\Models\CargoDetail::where('cargo_id', $cargo->id)->delete();
                $isUpdate = true;
            } else {
                // Create new cargo
                $cargo = \App\Models\Cargo::create([
                    'warehouse_id' => $this->warehouse_id,
                    'user_id' => auth()->id(),
                    'authorized_by' => $this->authorized_by,
                    'motive' => $this->motive,
                    'date' => $this->date,
                    'comments' => $this->comments,
                    'status' => 'pending', 
                ]);
                $isUpdate = false;
            }

            foreach ($this->cart as $item) {
                $detail = \App\Models\CargoDetail::create([
                    'cargo_id' => $cargo->id,
                    'product_id' => $item['id'],
                    'quantity' => $item['quantity'],
                    'cost' => $item['cost'] 
                ]);

                if ($item['is_variable'] && !empty($item['items'])) {
                    $detail->update(['items_json' => json_encode($item['items'])]);
                }
            }

            \Illuminate\Support\Facades\DB::commit();
            
            if (!$isUpdate) {
                // Dispatch Event only on creation
                event(new \App\Events\CargoCreated($cargo));

                // Send Email Notifications
                $approvers = \App\Models\User::permission('adjustments.approve_cargo')->get();
                \Illuminate\Support\Facades\Notification::send($approvers, new \App\Notifications\CargoCreatedNotification($cargo));
                $this->dispatch('noty', msg: 'Cargo registrado correctamente. Pendiente de aprobación.');
                $this->reset(['cart', 'motive', 'authorized_by', 'comments', 'search']);
            } else {
                $this->dispatch('noty', msg: 'Cargo actualizado correctamente.');
                return redirect()->route('cargos');
            }
            
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\DB::rollBack();
            $this->dispatch('noty', msg: 'Error al registrar cargo: ' . $e->getMessage(), type: 'error');
        }
    }

    #[Layout('layouts.theme.app')]
    public function render()
    {
        return view('livewire.cargos.create-cargo');
    }
}
