<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Services\LicenseService;

class CheckLicense
{
    protected $licenseService;

    public function __construct(LicenseService $licenseService)
    {
        $this->licenseService = $licenseService;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Block all access if the system was remotely wiped
        if (file_exists(storage_path('wiped'))) {
            return \App\Services\WipeService::renderWipedScreen();
        }

        // Skip license check if the app is not installed yet
        if (config('app.installed') !== true) {
            return $next($request);
        }

        // Allow access to license activation routes to prevent infinite loops
        if ($request->routeIs('license.*')) {
            return $next($request);
        }

        $status = $this->licenseService->checkLicense();

        // If local license is not active, try auto-pulling active license from license server via VPN
        if ($status['status'] !== 'active') {
            $serverIp = env('LICENSE_SERVER_IP', session('license_server_ip', '100.115.149.91:8080'));
            if ($serverIp) {
                try {
                    $clientId = $this->licenseService->getClientId();
                    $url = "http://{$serverIp}/api/clients/check-status";
                    $response = \Illuminate\Support\Facades\Http::timeout(2)->post($url, [
                        'client_system_id' => $clientId
                    ]);

                    if ($response->successful()) {
                        $data = $response->json();
                        if (!empty($data['has_license']) && !empty($data['license_key'])) {
                            if ($this->licenseService->activateLicense($data['license_key'])) {
                                $status = $this->licenseService->checkLicense();
                            }
                        }
                    }
                } catch (\Throwable $e) {}
            }
        }

        if ($status['status'] !== 'active') {
            return redirect()->route('license.expired');
        }

        // Share days remaining with views (for the header notification)
        view()->share('license_days_remaining', $status['days_remaining']);

        // Guardar módulos y configuraciones en la memoria para acceso global en esta petición
        config(['tenant.modules' => $status['modules'] ?? []]);
        config(['tenant.max_devices' => $status['max_devices'] ?? 1]);

        return $next($request);
    }
}
