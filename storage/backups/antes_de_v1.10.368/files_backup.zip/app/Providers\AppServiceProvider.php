<?php

namespace App\Providers;

use App\Helpers\Helper;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // Registro de helpers
        $this->app->singleton('fun', function () {
            return new Helper();
        });
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        \Illuminate\Support\Facades\View::composer('layouts.theme.header', \App\View\Composers\HeaderComposer::class);

        // Registro de directiva Blade para Módulos SaaS (Antiguo / Complementario)
        \Illuminate\Support\Facades\Blade::if('module', function ($moduleName) {
            try {
                $config = \App\Services\ConfigurationService::getConfig();
                if ($config && method_exists($config, 'hasAddon')) {
                    return $config->hasAddon($moduleName);
                }
            } catch (\Throwable $th) {}

            // Fallback en caso de que no haya DB (ej. en migraciones)
            $modules = config('tenant.modules', []);
            return in_array($moduleName, $modules);
        });

        // Registro de directiva Blade para Planes de Suscripción
        \Illuminate\Support\Facades\Blade::if('plan', function ($planName) {
            try {
                $config = \App\Services\ConfigurationService::getConfig();
                if ($config && method_exists($config, 'hasPlan')) {
                    return $config->hasPlan($planName);
                }
            } catch (\Throwable $th) {}
            return false; // Default false to enforce security
        });

        // Registro de directiva Blade para Add-ons a la carta
        \Illuminate\Support\Facades\Blade::if('addon', function ($addonName) {
            try {
                $config = \App\Services\ConfigurationService::getConfig();
                if ($config && method_exists($config, 'hasAddon')) {
                    return $config->hasAddon($addonName);
                }
            } catch (\Throwable $th) {}
            return false;
        });

        try {
            $config = \App\Services\ConfigurationService::getConfig();
            if ($config) {
                if (!empty($config->backup_emails)) {
                    config(['backup.notifications.mail.to' => $config->backup_emails]);
                }
                
                $businessName = $config->business_name ?? 'Sistema';
                // Sanitize business name
                $businessName = iconv('UTF-8', 'UTF-8//IGNORE', $businessName);
                $businessName = preg_replace('/[\x00-\x1F\x7F]/u', '', $businessName) ?? $businessName;

                $appName = "JSPOS(" . $businessName . ")";
                config([
                    'backup.backup.name' => $appName,
                    'mail.from.name' => $appName,
                    'app.name' => $appName
                ]);
            }
        } catch (\Throwable $th) {
            // Fails silently
        }

        // Auto-enable new treasury module in local environment for testing
        if (app()->environment('local')) {
            $modules = config('tenant.modules', []);
            if (!is_array($modules)) {
                $modules = [];
            }
            if (!in_array('module_treasury', $modules)) {
                $modules[] = 'module_treasury';
                config(['tenant.modules' => $modules]);
            }
        }
    }
}
